package com.rovers;

public class XY {
    public int x = 0;
    public int y = 0;
    public XY(int x , int y) {
        this.x = x ;
        this.y = y;
    }
}
